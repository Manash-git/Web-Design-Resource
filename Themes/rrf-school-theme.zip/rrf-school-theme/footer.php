<?php
    $select_footer_style = ot_get_option('select_footer_style');
    get_template_part('content/footer-'.$select_footer_style.''); ?>
    
    </div>   

    
        <?php wp_footer(); ?>      
    </body>
</html>
