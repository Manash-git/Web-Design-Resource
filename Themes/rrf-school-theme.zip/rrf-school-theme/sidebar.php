<div class="col-md-4">
    <div class="sidebar">
        <?php dynamic_sidebar('sidebar_widgets'); ?>
    </div>
</div>